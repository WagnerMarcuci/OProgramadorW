#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "sqlite3.h"

bool apagar_recriar_tabela( sqlite3 * );
bool ler_com_id( sqlite3 * );
bool ler_com_texto( sqlite3 * );
bool apagar_registro( sqlite3 * );
int sqlite3_retorno( void *, int, char **, char ** );

// ---------------------------------------------------------------------------------
int main()
{
    sqlite3 * db = 0;

    printf("versao: %s\n", sqlite3_libversion());

    int rc = sqlite3_open( "database.db3", &db );

    if ( rc != SQLITE_OK )
    {
        printf( "ERRO ao abrir: %s\n", sqlite3_errmsg( db ) );
        sqlite3_close( db );
        return 1;
    }

    if ( !apagar_recriar_tabela( db ) )
    {
        return 1;
    }

    printf( "\n-- LER COM ID --\n" );

    if ( !ler_com_id( db ) )
    {
        return 1;
    }

    printf( "\n-- LER COM TEXTO --\n" );

    if ( !ler_com_texto( db ) )
    {
        return 1;
    }

    printf( "\n-- APAGAR REGISTRO --\n" );

    if ( !apagar_registro( db ) )
    {
        return 1;
    }

    sqlite3_close(db);

    return 0;
}
// ---------------------------------------------------------------------------------
int sqlite3_retorno(void * sem_uso, int argc, char ** argv, char ** coluna)
{
    for( int i = 0; i < argc; i++)
    {
        printf("%s = %s\n", coluna[i], argv[i] ? argv[i] : "NULL");
    }

    printf("\n");
    return 0;
}
// ---------------------------------------------------------------------------------
bool apagar_recriar_tabela( sqlite3 * p_db )
{
    char * mensagem_erro = 0;
    char create[] = "DROP TABLE IF EXISTS funcionario;"
                    "CREATE TABLE funcionario( "
                    "id INTEGER PRIMARY KEY, "
                    "nome TEXT,"
                    "nascimento TEXT );"
                    "insert into funcionario(id,nome,nascimento) "
                    "values( 11, 'Teste 11', '14/11/1911');"
                    "insert into funcionario(id,nome,nascimento) "
                    "values( 22, 'Teste 22', '14/11/1922');"
                    "insert into funcionario(id,nome,nascimento) "
                    "values( 33, 'Teste 33', '14/11/1933');";

    int rc = sqlite3_exec( p_db, create, sqlite3_retorno, 0, &mensagem_erro );

    if ( rc != SQLITE_OK )
    {
        printf( "ERRO ao criar tabela funcionario: %s\n", sqlite3_errmsg( p_db ) );
        sqlite3_close( p_db );
        return false;
    }

    sqlite3_free( mensagem_erro );
    printf( "Tabela Funcionario criada.\n" );
    return true;
}
// ---------------------------------------------------------------------------------
bool ler_com_id( sqlite3 * p_db )
{
    sqlite3_stmt * handle_sql = 0;
    char comando_sql[] = "SELECT * FROM funcionario WHERE ID=?";

    int rc = sqlite3_prepare_v2( p_db, comando_sql, -1, &handle_sql, 0 );

    if ( rc != SQLITE_OK )
    {
        printf( "ERRO no prepare: %s\n", sqlite3_errmsg( p_db ) );
        return false;
    }

    //int sqlite3_bind_double(sqlite3_stmt*, int, double);
    //int sqlite3_bind_int(sqlite3_stmt*, int, int);
    //int sqlite3_bind_text(sqlite3_stmt*,int,const char*,int,void(*)(void*));
    //int sqlite3_bind_value(sqlite3_stmt*, int, const sqlite3_value*);
    rc = sqlite3_bind_int( handle_sql, 1, 22 );

    if ( rc != SQLITE_OK )
    {
        printf( "ERRO no bind: %s\n", sqlite3_errmsg( p_db ) );
        return false;
    }

    rc = sqlite3_step( handle_sql );

    if ( rc == SQLITE_ROW)
    {
        // retornar os valores dos campos se precisar
        printf("id........: %s\n", sqlite3_column_text(handle_sql, 0 ) );
        printf("nome......: %s\n", sqlite3_column_text(handle_sql, 1 ) );
        printf("nascimento: %s\n", sqlite3_column_text(handle_sql, 2 ) );
    }

    sqlite3_free( handle_sql );
    return true;
}
// ---------------------------------------------------------------------------------
bool ler_com_texto( sqlite3 * p_db )
{
    sqlite3_stmt * handle_sql = 0;
    char comando_sql[] = "SELECT * FROM funcionario WHERE nascimento=?";

    int rc = sqlite3_prepare_v2( p_db, comando_sql, -1, &handle_sql, 0 );

    if ( rc != SQLITE_OK )
    {
        printf( "ERRO no prepare: %s\n", sqlite3_errmsg( p_db ) );
        return false;
    }

    rc = sqlite3_bind_text( handle_sql, 1, "14/11/1922", -1, NULL );

    if ( rc != SQLITE_OK )
    {
        printf( "ERRO no bind: %s\n", sqlite3_errmsg( p_db ) );
        return false;
    }

    rc = sqlite3_step( handle_sql );

    if ( rc == SQLITE_ROW)
    {
        // retornar os valores dos campos se precisar
        printf("id........: %s\n", sqlite3_column_text(handle_sql, 0 ) );
        printf("nome......: %s\n", sqlite3_column_text(handle_sql, 1 ) );
        printf("nascimento: %s\n", sqlite3_column_text(handle_sql, 2 ) );
    }

    sqlite3_free( handle_sql );
    return true;
}
// ---------------------------------------------------------------------------------
bool apagar_registro( sqlite3 * p_db )
{
    sqlite3_stmt * handle_sql = 0;
    char comando_sql[] = "DELETE FROM funcionario WHERE id=?";

    int rc = sqlite3_prepare_v2( p_db, comando_sql, -1, &handle_sql, 0 );

    if ( rc != SQLITE_OK )
    {
        printf( "ERRO no prepare: %s\n", sqlite3_errmsg( p_db ) );
        return false;
    }

    rc = sqlite3_bind_int( handle_sql, 1, 33 );

    if ( rc != SQLITE_OK )
    {
        printf( "ERRO no bind: %s\n", sqlite3_errmsg( p_db ) );
        return false;
    }

    rc = sqlite3_step( handle_sql );

    if ( rc != SQLITE_DONE )
    {
        printf( "ERRO ao apagar registro.\n" );
        return false;
    }

    sqlite3_free( handle_sql );
    return true;

}
// ---------------------------------------------------------------------------------
