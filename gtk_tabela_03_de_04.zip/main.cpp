#include <gtk/gtk.h>

const int COLUNA_NUMERO = 0;
const int COLUNA_TEXTO = 1;

GtkListStore * g_store = 0;
GtkWidget * g_treeview = 0;

void on_row_activated(GtkTreeView *,
                      GtkTreePath *,
                      GtkTreeViewColumn *,
                      gpointer );

void on_columns_changed( GtkTreeView * );

void on_cursor_changed( GtkTreeView * );

void ler_todas_linha( void );

void limpar_tabela( void );

void click_botao( void )
{
  printf( "click_botao\n" );

  //ler_todas_linha();

  //limpar_tabela();
}

int main(int argc, char **argv)
{
  gtk_init(&argc, &argv);

  GtkBuilder * builder = gtk_builder_new_from_file( "tabela_treeview.ui" );
  GtkWidget * layout = GTK_WIDGET( gtk_builder_get_object( builder, "janela_layout" ) );
  GtkWidget * janela = GTK_WIDGET( gtk_builder_get_object( builder, "janela_principal" ) );
  GtkWidget * treeview = GTK_WIDGET( gtk_builder_get_object( builder, "treeview" ) );
  GtkWidget * botao = GTK_WIDGET( gtk_builder_get_object( builder, "botao" ) );

  g_treeview = treeview;
  gtk_window_resize( ( GtkWindow * )janela, 600, 500 );
  
  g_signal_connect ( botao, "clicked", G_CALLBACK( click_botao ), NULL);

  g_signal_connect( janela, "destroy", 
      G_CALLBACK( gtk_main_quit ), NULL);

  g_signal_connect( treeview, "row-activated", 
      G_CALLBACK( on_row_activated ), NULL);
  
  g_signal_connect ( treeview, "columns-changed", 
      G_CALLBACK( on_columns_changed ), NULL );

  g_signal_connect ( treeview, "cursor-changed", 
      G_CALLBACK( on_cursor_changed ), NULL);

  GtkCellRenderer * renderer = 0;

  renderer = gtk_cell_renderer_text_new();

  const int COLUNA_NUMERO = 0;
  const int COLUNA_TEXTO = 1;
  const int TOTAL_COLUNAS = 2;
  
  gtk_tree_view_insert_column_with_attributes(GTK_TREE_VIEW( treeview ),
                                               -1,      
                                               "Número",  
                                               renderer,
                                               "text", 
                                               COLUNA_NUMERO,
                                               NULL);

  renderer = gtk_cell_renderer_text_new();
  gtk_tree_view_insert_column_with_attributes(GTK_TREE_VIEW( treeview ),
                                               -1,      
                                               "Texto",  
                                               renderer,
                                               "text", 
                                               COLUNA_TEXTO,
                                               NULL);


  //
  // criar o modelo de dados ( conteudo das linhas e colunas )
  //
  g_store = gtk_list_store_new( TOTAL_COLUNAS,
                                G_TYPE_UINT,
                                G_TYPE_STRING );

  GtkTreeIter iter;

  // 1a. linha
  gtk_list_store_append( g_store, &iter);

  gtk_list_store_set( g_store, 
                      &iter,
                      COLUNA_NUMERO, 
                      001,
                      COLUNA_TEXTO,
                      "Texto do item 001",
                      -1 );

  // 2a. linha
  gtk_list_store_append( g_store, &iter);

  gtk_list_store_set( g_store, 
                      &iter,
                      COLUNA_NUMERO, 
                      002,
                      COLUNA_TEXTO,
                      "Texto do item 002",
                      -1 );

  // 3a. linha
  gtk_list_store_append( g_store, &iter);

  gtk_list_store_set( g_store, 
                      &iter,
                      COLUNA_NUMERO, 
                      003,
                      COLUNA_TEXTO, 
                      "Texto do item 003",
                      -1 );

  GtkTreeModel * modelo = GTK_TREE_MODEL( g_store );

  //
  // adicionar o modelo ao treeview
  //
  gtk_tree_view_set_model(GTK_TREE_VIEW( treeview ), modelo );

  //
  // modelo ja copiado para a arvore ou ele sera desalocado
  // da memoria ao termino do programa ou voce pode 
  // executar o comando abaixo
  g_object_unref( modelo );


  gtk_widget_show_all( janela );

  gtk_main();

  return 0;
}

// ------------------------------------------------------------------
void on_row_activated(GtkTreeView        * view,
                      GtkTreePath        * path,
                      GtkTreeViewColumn  * col,
                      gpointer           user_data )
{
  printf( "on_row_activated => double click\n" );
}
// ------------------------------------------------------------------
void on_columns_changed( GtkTreeView * view )
{
  printf( "on_columns_changed\n" );
}
// ------------------------------------------------------------------
void on_cursor_changed( GtkTreeView * view )
{
  printf( "on_cursor_changed=> click\n" );
}
// ------------------------------------------------------------------
void ler_todas_linha( void )
{
  GtkTreeIter iter;
  gboolean isProximoRegistro = FALSE;

  isProximoRegistro = 
    gtk_tree_model_get_iter_first(GTK_TREE_MODEL( g_store ), &iter);

  while( isProximoRegistro )    
  {
      int valor = 0;
      char * conteudo = 0;

      gtk_tree_model_get ( GTK_TREE_MODEL( g_store), 
                          &iter, 
                          COLUNA_NUMERO, 
                          &valor, 
                          COLUNA_TEXTO, 
                          &conteudo, 
                          -1 );

      printf( "%d - %s\n", valor, conteudo );
      
      isProximoRegistro = 
        gtk_tree_model_iter_next(GTK_TREE_MODEL( g_store ), &iter);
  }
}
// ------------------------------------------------------------------
void limpar_tabela( void )
{
  gtk_tree_view_set_model(GTK_TREE_VIEW( g_treeview ), NULL);  
}
// ------------------------------------------------------------------
