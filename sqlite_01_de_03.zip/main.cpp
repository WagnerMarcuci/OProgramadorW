#include <stdio.h>
#include <stdlib.h>
#include "sqlite3.h"

int sqlite3_retorno(void *NotUsed, int argc, char **argv, char **coluna)
{
    for( int i = 0; i < argc; i++)
    {
        printf("%s = %s\n", coluna[i], argv[i] ? argv[i] : "NULL");
    }

    printf("\n");
    return 0;
}

int main()
{
    sqlite3 * db = 0;
    char * mensagem_erro = 0;

    printf("versao: %s\n", sqlite3_libversion());

    int rc = sqlite3_open( "database.db3", &db );

    if ( rc != SQLITE_OK )
    {
        printf( "ERRO ao abrir: %s\n", sqlite3_errmsg( db ) );
        sqlite3_close( db );
        return 1;
    }

//    // criando uma tabela dentro do arquivo
//    char create[] = "CREATE TABLE funcionario( "
//                    "id INTEGER PRIMARY KEY, "
//                    "nome TEXT,"
//                    "nascimento TEXT )";
//
//    rc = sqlite3_exec( db, create, sqlite3_retorno, 0, mensagem_erro );
//
//    if ( rc != SQLITE_OK )
//    {
//        printf( "ERRO ao criar tabela funcionario: %s\n", sqlite3_errmsg( db ) );
//        sqlite3_close( db );
//        return 1;
//    }
//
//    printf( "Tabela Funcionario criada.\n" );



//    // incluir dados na tabela funcionario
//    char insert[] = "insert into funcionario(id,nome,nascimento) "
//                    "values( 2, 'Teste', '14/11/1971') ";
//
//    rc = sqlite3_exec( db, insert, sqlite3_retorno, 0, mensagem_erro );
//
//    if ( rc != SQLITE_OK )
//    {
//        printf( "ERRO no insert tabela funcionario: %s\n", sqlite3_errmsg( db ) );
//        sqlite3_close( db );
//        return 1;
//    }
//
//    printf( "Insert da tabela Funcionario executada.\n" );



//    // obter um registro
//    char query[] = "select * from funcionario where id=1";
////    char query[] = "select * from funcionario"; // todos os registros
//
//
//    rc = sqlite3_exec( db, query, sqlite3_retorno, 0, mensagem_erro );
//
//    if ( rc != SQLITE_OK )
//    {
//        printf( "ERRO ao consultar funcionario: %s\n", sqlite3_errmsg( db ) );
//        sqlite3_close( db );
//        return 1;
//    }
//
//    printf( "Consulta executada com sucesso.\n" );



    // atualizar registro
    char update[] = "update funcionario set nome='qualquer nome', "
                                          "nascimento='99/99/99' "
                                          "where id=2";
//    char update[] = "select * from funcionario"; // todos os registros


    rc = sqlite3_exec( db, update, sqlite3_retorno, 0, &mensagem_erro );

    if ( rc != SQLITE_OK )
    {
        printf( "ERRO ao atualizar funcionario: %s\n", sqlite3_errmsg( db ) );
        sqlite3_close( db );
        return 1;
    }

    printf( "Atualizacao executada com sucesso.\n" );

    // consultar se atualizacao teve efeito
    char query[] = "select * from funcionario where id=2";

    rc = sqlite3_exec( db, query, sqlite3_retorno, 0, &mensagem_erro );

    if ( rc != SQLITE_OK )
    {
        printf( "ERRO ao consultar funcionario: %s\n", sqlite3_errmsg( db ) );
        sqlite3_close( db );
        return 1;
    }

    printf( "Consulta executada com sucesso.\n" );


    // DROP TABLE IF EXISTS funcionario

    sqlite3_free( mensagem_erro );
    sqlite3_close(db);

    return 0;
}


/** documentacao sqlite
 *  https://www.sqlite.org/index.html
 */
