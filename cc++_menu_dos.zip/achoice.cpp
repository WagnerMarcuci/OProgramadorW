#include "achoice.h"

//-----------------------------------------------------------------------------
Achoice::Achoice()
{
    this->handle = GetStdHandle( STD_OUTPUT_HANDLE );
    this->clear();
}
//-----------------------------------------------------------------------------
Achoice::~Achoice()
{

}
//-----------------------------------------------------------------------------
void Achoice::setXY( int x, int y )
{
    const COORD coord = { x, y };

    if ( this->primeiro_item.X == -1 && this->primeiro_item.Y == -1 )
    {
        this->primeiro_item = coord;
    }

    SetConsoleCursorPosition( this->handle, coord);
}
//-----------------------------------------------------------------------------
COORD Achoice::getXY( void )
{
    CONSOLE_SCREEN_BUFFER_INFO pos;
    COORD coord;
    BOOL rc = GetConsoleScreenBufferInfo( this->handle, &pos );

    coord.X = pos.dwCursorPosition.X;
    coord.Y = pos.dwCursorPosition.Y;
    return coord;
}
//-----------------------------------------------------------------------------
void Achoice::insert_item_menu( std::string p_item )
{
    this->insert_item_menu( ( char * )p_item.c_str() );
}
//-----------------------------------------------------------------------------
void Achoice::insert_item_menu( char * p_item )
{
    std::string tmp = "  ";
    tmp += p_item;
    tmp += "  ";
    this->menu.push_back( tmp );

    if ( ( int )tmp.size() > this->item_tamanho )
    {
        this->item_tamanho = ( int )tmp.size();
    }
}
//-----------------------------------------------------------------------------
int Achoice::choice( void )
{
    if ( this->primeiro_item.X == -1 && this->primeiro_item.Y == -1 )
    {
        this->primeiro_item = this->getXY();
    }

    COORD xy = this->primeiro_item;
    this->item_qtde = ( int )this->menu.size() - 1;
    this->montar_linha();

    this->setXY( xy.X, xy.Y );
    char ch = 201;
    std::cout << "  " << ch;
    ch = 205;

    for( int i = 1; i < this->item_tamanho + 2; ++i )
    {
        std::cout  << ch;
    }

    ch = 187;
    std::cout << ch;

    ++xy.Y;
    ++this->primeiro_item.Y;

    ch = 186;

    for( int i = 0; i <= this->item_qtde; ++i )
    {
        this->setXY( xy.X, xy.Y + i );

        if ( i == 0 )
        {
            std::cout << "  " << ch << ">" << this->menu.at( 0 ) << ch;
            continue;
        }

        std::cout << "  " << ch << " " << this->menu.at( i ) << ch;
    }

    this->setXY( xy.X, xy.Y + this->item_qtde + 1 );
    ch = 200;
    std::cout << "  " << ch;
    ch = 205;

    for( int i = 1; i < this->item_tamanho + 2; ++i )
    {
        std::cout << ch;
    }

    ch = 188;
    std::cout << ch;

    this->setXY( xy.X, xy.Y );
    this->tela_posicao = 0;
    GetAsyncKeyState( VK_RETURN ) & 0x00000001 ; // ler ENTER e descartar

    while( true )
    {
        if ( GetAsyncKeyState( VK_UP ) & 0x00000001 )
        {
            this->controlar_menu( -1 );
        }

        if ( GetAsyncKeyState( VK_DOWN ) & 0x00000001 )
        {
            this->controlar_menu( +1 );
        }

        if ( GetAsyncKeyState( VK_RETURN ) & 0x00000001 )
        {
            this->setXY( this->primeiro_item.X, this->primeiro_item.Y + this->item_qtde + 2 );
            return this->tela_posicao + 1;
        }

        Sleep( 10 );
    }
}
//-----------------------------------------------------------------------------
void Achoice::controlar_menu( int p_direcao )
{
    const COORD xy = this->primeiro_item;
    int pos_anterior = this->tela_posicao;
    int pos_atual = pos_anterior + p_direcao;

    if ( pos_atual == -1 )
    {
        pos_anterior = 0;
        pos_atual = this->item_qtde;
    }

    if ( pos_atual > this->item_qtde )
    {
        pos_anterior = this->item_qtde;
        pos_atual = 0;
    }

    const char ch = 186;
    this->setXY( xy.X, xy.Y + pos_anterior );
    std::cout << "  " << ch << " " << this->menu.at( pos_anterior ) << ch;
    this->setXY( xy.X, xy.Y + pos_atual );
    std::cout << "  " << ch << ">" << this->menu.at( pos_atual ) << ch;
    this->tela_posicao = pos_atual;
}
//-----------------------------------------------------------------------------
void Achoice::clear( void )
{
    this->primeiro_item = { -1, -1 };
    this->item_qtde = 0;
    this->item_tamanho = 0;
    this->tela_posicao = 0;
    this->menu.clear();
}
//-----------------------------------------------------------------------------
void Achoice::montar_linha( void )
{
    std::vector< std::string >tmp( this->menu );
    this->menu.clear();
    this->menu.reserve( this->item_qtde );

    for( int i = 0; i < ( int )tmp.size(); ++i )
    {
        std::string linha = tmp.at( i );

        for( int j = ( int )linha.size(); j < this->item_tamanho; ++j )
        {
            linha += " ";
        }

        this->menu.push_back( linha );
    }
}
//-----------------------------------------------------------------------------

