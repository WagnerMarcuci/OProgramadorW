#ifndef ACHOICE_H
#define ACHOICE_H
#include <windows.h>
#include <vector>
#include <string>
#include <iostream>

class Achoice
{
    public:
        /**
         * @brief construtora
         */
        Achoice();

        /**
         * @brief destrutora
         */
        ~Achoice();

        /**
         * @brief setar coordenadas x,y na tela
         * @param [in] x
         * @param [in] y
         */
        void setXY( int, int );

        /**
         * @brief obter coordenadas x,y da tela
         * @return estrutura COORD
         */
        COORD getXY( void );

        /**
         * @brief incluir item no menu
         * @param texto do item
         */
        void insert_item_menu( char * );
        void insert_item_menu( std::string );

        /**
         * @brief selecionar a opcao
         * @return numero da opcao
         */
        int choice( void );

        /**
         * @brief inicializar o menu
         */
        void clear( void );

    private:
        COORD primeiro_item;
        HANDLE handle;
        std::vector< std::string > menu;
        void controlar_menu( int );
        void montar_linha( void );
        int item_qtde;
        int item_tamanho;
        int tela_posicao;
};

#endif // ACHOICE_H
