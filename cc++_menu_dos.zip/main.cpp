#include <iostream>
#include <windows.h>
#include "Achoice.h"

int main()
{
    system( "cls" );
    Achoice achoice;
    COORD xy;

    achoice.setXY( 50, 10 );
    achoice.insert_item_menu( "1. item 1" );
    achoice.insert_item_menu( "2. item 2" );
    achoice.insert_item_menu( "3. item 3" );
    achoice.insert_item_menu( "4. item 4" );
    int pos = achoice.choice();

    std::cout << "posicao: " << pos << std::endl;

    achoice.clear();
    achoice.insert_item_menu( "1. item 1" );
    achoice.insert_item_menu( "2. item 2" );
    achoice.insert_item_menu( "3. item 3" );
    pos = achoice.choice();

    std::cout << "posicao: " << pos << std::endl;

    system ("pause");
    return 0;
}
