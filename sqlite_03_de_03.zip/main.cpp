#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "sqlite3.h"

bool apagar_recriar_tabela( sqlite3 * );
bool ler_com_bind( sqlite3 * );
bool ler_todos_registros( sqlite3 * );
int sqlite3_retorno( void *, int, char **, char ** );

// ---------------------------------------------------------------------------------
int main()
{
    sqlite3 * db = 0;

    printf("versao: %s\n", sqlite3_libversion());

    int rc = sqlite3_open( "database.db3", &db );

    if ( rc != SQLITE_OK )
    {
        printf( "ERRO ao abrir: %s\n", sqlite3_errmsg( db ) );
        sqlite3_close( db );
        return 1;
    }

    if ( !apagar_recriar_tabela( db ) )
    {
        return 1;
    }

    printf( "\n--- LER-COM-BIND ---\n" );

    if ( !ler_com_bind( db ) )
    {
        return 1;
    }

    printf( "\n--- LER-TODOS-REGISTROS ---\n" );

    if ( !ler_todos_registros( db ) )
    {
        return 1;
    }

    sqlite3_close(db);

    return 0;
}
// ---------------------------------------------------------------------------------
int sqlite3_retorno(void * sem_uso, int argc, char ** argv, char ** coluna)
{
    for( int i = 0; i < argc; i++)
    {
        printf("%s = %s\n", coluna[i], argv[i] ? argv[i] : "NULL");
    }

    printf("\n");
    return 0;
}
// ---------------------------------------------------------------------------------
bool apagar_recriar_tabela( sqlite3 * p_db )
{
    char * mensagem_erro = 0;
    char create[] = "DROP TABLE IF EXISTS funcionario;"
                    "CREATE TABLE funcionario( "
                    "id INTEGER PRIMARY KEY, "
                    "nome TEXT,"
                    "nascimento TEXT );"
                    "insert into funcionario(id,nome,nascimento) "
                    "values( 11, 'Teste 11', '14/11/1911');"
                    "insert into funcionario(id,nome,nascimento) "
                    "values( 22, 'Teste 22', '14/11/1922');"
                    "insert into funcionario(id,nome,nascimento) "
                    "values( 33, 'Teste 33', '14/11/1933');";

    int rc = sqlite3_exec( p_db, create, sqlite3_retorno, 0, &mensagem_erro );

    if ( rc != SQLITE_OK )
    {
        printf( "ERRO ao criar tabela funcionario: %s\n", sqlite3_errmsg( p_db ) );
        sqlite3_close( p_db );
        return false;
    }

    sqlite3_free( mensagem_erro );
    printf( "Tabela Funcionario criada.\n" );
    return true;
}
// ---------------------------------------------------------------------------------
bool ler_com_bind( sqlite3 * p_db )
{
    sqlite3_stmt * handle_sql = 0;
    char comando_sql[] = "SELECT nome FROM funcionario WHERE id=@id";

    int rc = sqlite3_prepare_v2( p_db, comando_sql, -1, &handle_sql, 0 );

    if ( rc != SQLITE_OK )
    {
        printf( "ERRO no prepare: %s\n", sqlite3_errmsg( p_db ) );
        return false;
    }

    // ao inves de dizer o numero do parametro vamos encontrar sua posicao
    const int posicao = sqlite3_bind_parameter_index( handle_sql, "@id" );
    rc = sqlite3_bind_int( handle_sql, posicao, 22 );

    if ( rc != SQLITE_OK )
    {
        printf( "ERRO no bind: %s\n", sqlite3_errmsg( p_db ) );
        return false;
    }

    rc = sqlite3_step( handle_sql );

    if ( rc != SQLITE_ROW )
    {
        printf( "ERRO ao executar: %s\n", sqlite3_errmsg( p_db ) );
        return false;
    }

    printf("nome: %s\n", sqlite3_column_text( handle_sql, 0 ) );
    return true;
}
// ---------------------------------------------------------------------------------
bool ler_todos_registros( sqlite3 * p_db )
{
    sqlite3_stmt * handle_sql = 0;
    char comando_sql[] = "SELECT id,nome FROM funcionario";

    int rc = sqlite3_prepare_v2( p_db, comando_sql, -1, &handle_sql, 0 );

    if ( rc != SQLITE_OK )
    {
        printf( "ERRO no prepare: %s\n", sqlite3_errmsg( p_db ) );
        return false;
    }

    while( true )
    {
        rc = sqlite3_step( handle_sql );

        if ( rc == SQLITE_DONE )
        {
            printf( "NAO HA MAIS REGISTROS.\n" );
            break;
        }

        if ( rc == SQLITE_ROW )
        {
            printf("id  : %s\n", sqlite3_column_text( handle_sql, 0 ) );
            printf("nome: %s\n\n", sqlite3_column_text( handle_sql, 1 ) );
        }
        else
        {
            printf( "ERRO ao executar: %s\n", sqlite3_errmsg( p_db ) );
            return false;
        }
    }

    return true;
}
// ---------------------------------------------------------------------------------
